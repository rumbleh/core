--------------------------------------------------------------------------------
SpkToolbar
--------------------------------------------------------------------------------

SpkToolbar is a ribbon-like toolbar.

Usage:
  Drop a TSpkToolbar component onto the form
  Double-click it and use the editor window to add tabs, panes and buttons.

Original author: Spook. 
Ported to Lazarus/LCL by Luiz Am�rico and Werner Pamler

License: 
  Modified LGPL (with linking exception, like Lazarus LCL)
  See "license.txt" in this installation  
         
Images and icons used
  The icons are taken from the FatCow icon set 
  (http://www.fatcow.com/free-icons, license Creative Commons Attribution 3.0).
  Some images are combinations of individual images.
  
  The component palette icon is drawn by Roland Hahn (free, no restrictions
  in usage).
  
  
         