List of directories:
- bgrabitmap: contains BGRABitmap library
- dev: tools used to make BGRABitmap
- test: contains a series of test programs and examples on how to use BGRABitmap library
