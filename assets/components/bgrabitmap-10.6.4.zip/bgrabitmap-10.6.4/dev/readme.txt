List of directories:
- makedoc: contains a program to make documentation from source code
- colorspace: contains a program to generate code for colorspaces
- parseunicode: parse the data provided by unicode and test unicode algorithm
- releaser: program to update BGRABitmap version for release

